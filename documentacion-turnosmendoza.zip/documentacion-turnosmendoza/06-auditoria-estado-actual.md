# Informe de Auditoría y Plan Estratégico de Lanzamiento

**Proyecto:** TurnosMendoza  
**Fecha:** Agosto 2026  
**Rol del análisis:** Product Manager + Tech Lead Senior

---

## 1. Resumen Ejecutivo

| Concepto | Valor |
|----------|-------|
| **Completitud real hacia producción** | **65%** |
| Frontend + UX | 95% |
| Backend + Persistencia + Pagos | 35% |

### Fortalezas principales
1. Propuesta de valor ultra-clara (seña Mercado Pago + WhatsApp)
2. Diseño Bento Grid de alto impacto (no parece plantilla genérica)
3. Fricción mínima para el paciente (sin registro ni app)

### Riesgos principales
1. Falsa sensación de “listo para lanzar” (el pago actual es simulado)
2. Complejidad de Mercado Pago Connect si cada profesional cobra en su cuenta

---

## 2. Auditoría por Capas

| Capa | Estado | % | Diagnóstico |
|------|--------|---|-------------|
| Diseño UX/UI y Flujos | Completo | 100% | Bento Grid coherente, responsive, paleta definida |
| Frontend (Páginas) | Completo | 95% | Home, Reserva, Dashboard, Login, Registro generados |
| Backend & DB (Prisma) | Parcial | 40% | Schema diseñado, no instanciado en Postgres real |
| Autenticación | Parcial | 40% | Interfaz lista, falta NextAuth + bcrypt en DB |
| Mercado Pago | Parcial | 30% | Endpoints programados, falta token real + webhook |
| Emails (Resend) | Parcial | 25% | Templates listos, falta API Key |
| Infraestructura | Parcial | 50% | Corre en Vite; falta migrar a Next.js + hosting |
| Contenido Semilla | Completo | 90% | Datos de Mendoza bien contextualizados |

---

## 3. Brechas Críticas (Gaps)

1. **Persistencia real** → Las citas mueren al recargar la página
2. **Checkout Pro real de Mercado Pago** → Reemplazar simulación por `init_point`
3. **Webhook de confirmación** → Cambiar estado a CONFIRMED y disparar email
4. **Autenticación de sesión real** → Proteger `/dashboard/*`
5. **Dominio + WhatsApp + Emails** → Configurar para que no caigan en spam

---

## 4. Recomendaciones de Avance

### 🔴 Inmediato (3-5 días) — Hacerlo Transaccional
- Crear base de datos en Neon/Supabase (Free Tier)
- Ejecutar `schema.prisma` + seed con profesionales de Mendoza
- Conectar Mercado Pago Sandbox
- Levantar el proyecto en Next.js 15

### 🟡 Corto Plazo (1-2 semanas) — Soft Launch
- Conectar Resend (emails de confirmación)
- Onboarding manual de 15 profesionales pioneros
- Testing de campo en Mobile (apertura de WhatsApp)

### 🟢 Mediano Plazo (Post-lanzamiento)
- Cobro de suscripción mensual recurrente
- Google Calendar sync
- Recordatorios automáticos por WhatsApp API oficial

---

## 5. Recomendación Estratégica

**NO REHACER NADA VISUAL.**  
Reutilizar el 100% del frontend actual.

**Camino más rápido (Time to Market < 7 días):**
1. Crear repositorio Next.js 15 limpio
2. Pegar componentes visuales ya generados
3. Conectar Prisma + Mercado Pago siguiendo la Guía Maestra

---

## 6. Checklist de Lanzamiento Mínimo (Go / No-Go)

Antes de invitar al primer profesional o cobrar el primer fee:

- [ ] 1. Base de datos Postgres en producción con backups
- [ ] 2. Cuenta oficial de Mercado Pago activa (credenciales de producción)
- [ ] 3. Webhook de Mercado Pago testeado (pago → CONFIRMED)
- [ ] 4. Enlaces de WhatsApp en formato +54 9 261...
- [ ] 5. Al menos 15 perfiles reales con matrícula y foto
- [ ] 6. Términos y Condiciones + Política de Cancelación de Señas
- [ ] 7. Certificado SSL (HTTPS) en dominio definitivo
- [ ] 8. Email transaccional que llega a bandeja de entrada (no Spam)
- [ ] 9. Login de profesionales seguro
- [ ] 10. Prueba E2E con $100 reales (reservar → pagar → confirmar → WhatsApp)
