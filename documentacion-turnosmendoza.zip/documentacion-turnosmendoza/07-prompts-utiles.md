# Colección de Prompts Útiles — TurnosMendoza

Prompts generados y refinados durante el proceso de definición y construcción del PMV.

---

## 1. Prompt de Stack Técnico (Google AI Studio – Modo Automate)

```
Actúa como un arquitecto de software senior especializado en MVPs económicos y rápidos para el mercado argentino.

Necesito que generes, en UNA SOLA SESIÓN, la estructura completa y lista para implementar del stack técnico del siguiente MVP:

Producto: Portal web multi-profesión (médicos, abogados, contadores, escribanos) enfocado en Mendoza...
[Stack: Next.js + Prisma + Mercado Pago + etc.]

Entrega: Arquitectura, estructura de carpetas, modelo de datos, endpoints, .env.example, pasos de despliegue, código base mínimo, estimación de costos.
```

---

## 2. Prompt de Home Comercial + Workflows + Roadmap

```
Actúa como Product Designer + UX/UI Lead + Product Manager senior...

Contexto: estética Bento Grid ya definida (#F8FAFC, #1F2937, #0081C9)...

Generá:
1. Home Comercial completo
2. Workflow completo del Paciente
3. Workflow completo del Profesional
4. Roadmap de cierre del PMV
5. Micro-interacciones y estados clave
```

---

## 3. Prompt de Verificación de Código Real

```
Actúa como Auditor Técnico Senior + QA Lead...

Generá un Informe Real de Estado del Código con:
1. Resumen Ejecutivo
2. Checklist de Componentes Críticos (Landing, Auth, Dashboard, Reserva, Infra)
3. Evidencia de Código Real (archivos + fragmentos)
4. Gaps y Problemas Detectados
5. Veredicto Final
```

---

## 4. Prompt de Rutas para QA Testing

```
Actúa como QA Lead del proyecto TurnosMendoza.

Generá una lista clara de todas las URLs / rutas disponibles para pruebas de QA.

Formato: tabla con # | URL/Ruta | Descripción | Tipo de usuario | Qué probar
+ Notas para QA (dispositivos + Critical Paths)
```

---

## 5. Prompt de Rutas Reales en Next.js

```
Actúa como Desarrollador Senior Full-Stack especializado en Next.js 15 App Router...

Convertí los flujos actuales (modales) en rutas reales:
- /login, /registro, /dashboard/*, /reserva/[profesionalId], /profesional/[id], etc.

Entregá: estructura de carpetas, código base de cada page.tsx, middleware, ejemplo de migración de un Modal a ruta.
```

---

## 6. Prompt de Migración Completa a Producción

```
Actúa como Arquitecto Full-Stack Senior...

Migrar el prototipo Vite + React a:
Next.js 15 + Prisma + NextAuth + Mercado Pago + Resend

Entregá: estructura de carpetas, schema.prisma, auth, middleware, endpoints MP, plan de migración paso a paso, .env.example
```

---

## 7. Prompt de Páginas UX/UI Faltantes

```
Actúa como Senior UI/UX Designer + Frontend Developer...

Generá el código completo de las páginas que faltan para cerrar el diseño UX/UI del PMV:
- /login
- /registro
- /profesional/[id]
- /dashboard/turnos
- /dashboard/aranceles
- /dashboard/plan
- /reserva/confirmacion/[id]

Mantener estética Bento Grid y paleta definida.
```

---

## 8. Prompt de Auditoría + Recomendaciones de Avance

```
Actúa como Product Manager + Tech Lead Senior...

Realizá una Auditoría completa del estado actual y entregá recomendaciones claras de avance.

Estructura:
1. Resumen Ejecutivo
2. Auditoría por Capas
3. Brechas Críticas
4. Recomendaciones priorizadas (Inmediato / Corto / Mediano plazo)
5. Recomendación estratégica
6. Checklist de Lanzamiento Mínimo
```
