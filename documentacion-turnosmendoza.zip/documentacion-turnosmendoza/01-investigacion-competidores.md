# Investigación de Competidores — TurnosMendoza

**Proyecto:** Portal multi-profesión (médicos, abogados, contadores, escribanos)  
**Ubicación estratégica:** Gran Mendoza (Ciudad, Las Heras, Godoy Cruz, Guaymallén)  
**Referencia principal:** Doctoralia  
**Fecha:** Agosto 2026

---

## 1. Competidores Internacionales (similares a Doctoralia)

| Plataforma | Enfoque | Fortalezas | Modelo de negocio |
|------------|---------|------------|-------------------|
| **Doctoralia** (Docplanner) | Marketplace médico + agenda | Alta visibilidad, reseñas, reserva online | Suscripción mensual/anual |
| **Zocdoc** (EE.UU.) | Búsqueda + reserva | Filtro por seguro, recordatorios | Suscripción |
| **Practo** (India / SEA) | Citas + telemedicina | Historial y servicios adicionales | Suscripción + comisiones |
| **Top Doctors** | Selectivo (top 10%) | Calidad sobre volumen, reseñas verificadas | Premium |
| **Healthgrades** | Información + reseñas | Transparencia de médicos y hospitales | Mixto |
| **Doctolib** (Europa) | Agenda avanzada | Integración con sistemas de salud | Suscripción |

---

## 2. Competidores Argentinos — Sector Salud

| Plataforma | Tipo | Fortalezas | Debilidades | Modelo |
|------------|------|------------|-------------|--------|
| **Doctoralia AR** | Marketplace + agenda | Tráfico masivo, reseñas | Precios altos, contratos anuales | ~$25.000–55.000 ARS/mes |
| **Crontu** | Marketplace de turnos | Búsqueda por zona y cobertura | Solo salud, reciente | Relacionado a Grupo Cormos |
| **MedicalCare** | Ficha + turnos + recetas | Fácil de armar, WhatsApp, freemium | Menos directorio masivo | Freemium + planes ARS |
| **Medra** | Software de consultorio | Agenda, recetas, nomenclador | Orientado a gestión interna | Desde ~USD 9/mes |
| **Turnito / Turnero Online / Turnera** | Agenda de turnos | Simples, económicos, Mercado Pago | Poca función de directorio | Planes en ARS |
| **Mederi / Abcmedico** | Directorios | Listados de profesionales | Sin reserva online robusta | Listado |

---

## 3. Competidores Argentinos — Legal / Contable / Notarial

| Plataforma | Descripción | ¿Tiene reserva? | Observaciones |
|------------|-------------|-----------------|---------------|
| **Abogados.com.ar** | Directorio de abogados y estudios | No | Más informativo/reputacional |
| **EscribanosOnline** | Directorio de escribanos con opiniones | Sí | Uno de los más cercanos |
| **TurnoLink** | Agenda específica para abogados, contadores y escribanos | Sí | Cobro de honorarios, formularios pre-consulta |
| **ReservaSimple / Citalo / AgendaOn** | Sistemas de turnos genéricos | Sí | El profesional comparte su link (no hay buscador central) |
| **CoreDesk Legal** | Directorio de abogados verificados (LATAM) | Consultas | Métricas de reputación |

---

## 4. Conclusión de la investigación

- **No existe** un portal local multi-profesión con buscador + ficha completa + reserva + seña Mercado Pago enfocado en el Gran Mendoza.
- Doctoralia domina en **captación** de pacientes médicos.
- Las soluciones locales ganan en precio en pesos, WhatsApp y Mercado Pago.
- En legal/contable/notarial el vacío es aún mayor (casi no hay marketplaces con reserva).

### Oportunidad clara
Un portal **hiperlocal + multi-profesión** con:
- Buscador por zona (Ciudad, Las Heras, Godoy Cruz, Guaymallén)
- Ficha completa
- Reserva online
- Seña con Mercado Pago
- Modelo de fee de despliegue + cuota mensual
