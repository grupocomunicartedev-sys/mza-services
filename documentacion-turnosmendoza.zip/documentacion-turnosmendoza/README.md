# Documentación TurnosMendoza — PMV

**Portal multi-profesión para el Gran Mendoza**  
Médicos · Abogados · Contadores · Escribanos  
Ciudad · Las Heras · Godoy Cruz · Guaymallén

---

## Índice de archivos

| # | Archivo | Contenido |
|---|---------|-----------|
| 01 | [01-investigacion-competidores.md](./01-investigacion-competidores.md) | Análisis de competidores (Doctoralia, alternativas argentinas e internacionales) |
| 02 | [02-planes-precios.md](./02-planes-precios.md) | Estructura de planes de precios en ARS + integración Mercado Pago |
| 03 | [03-estructura-mvp.md](./03-estructura-mvp.md) | Definición funcional del MVP (features, roles, entidades, flujos, criterios de done) |
| 04 | [04-definicion-producto-ux.md](./04-definicion-producto-ux.md) | Documento de Producto y UX/UI (Home Bento Grid, workflows paciente/profesional, roadmap) |
| 05 | [05-guia-migracion-nextjs.md](./05-guia-migracion-nextjs.md) | Guía maestra de migración a Next.js 15 + Prisma + Auth + Mercado Pago |
| 06 | [06-auditoria-estado-actual.md](./06-auditoria-estado-actual.md) | Auditoría completa del estado del proyecto + plan estratégico de lanzamiento |
| 07 | [07-prompts-utiles.md](./07-prompts-utiles.md) | Colección de prompts reutilizables generados durante el proceso |

---

## Estado actual del proyecto (resumen)

| Capa | Completitud |
|------|-------------|
| Diseño UX/UI + Flujos | 100% |
| Frontend (páginas y componentes) | 95% |
| Backend + Base de datos | 40% |
| Autenticación real | 40% |
| Mercado Pago real | 30% |
| **PMV usable en producción** | **≈ 65%** |

---

## Próximo paso recomendado

1. Crear repositorio Next.js 15
2. Aplicar la Guía de Migración (`05-guia-migracion-nextjs.md`)
3. Conectar Neon/Supabase + Mercado Pago Sandbox
4. Cargar 15 profesionales reales de Mendoza
5. Ejecutar el Checklist de Lanzamiento Mínimo (`06-auditoria-estado-actual.md`)

---

## Stack objetivo

- **Frontend:** Next.js 15 (App Router) + TypeScript + Tailwind
- **Backend / DB:** Prisma + PostgreSQL (Neon o Supabase)
- **Auth:** Auth.js (NextAuth v5)
- **Pagos:** Mercado Pago Checkout Pro
- **Emails:** Resend
- **Hosting recomendado:** Railway / Cloudflare Pages / Hetzner + Coolify

---

*Documentación generada y organizada a partir del proceso de definición del PMV — Agosto 2026*
