# Definición de Producto y UX/UI — PMV TurnosMendoza

**Documento consolidado de especificación funcional, de diseño y de producto.**  
**Fecha:** Agosto 2026

---

## 1. Home Comercial (Bento Grid)

### Estructura Desktop

```
┌──────────────────────────────────────────────────────────────────────────┐
│ [TOP BANNER] Gran Mendoza (Ciudad, Godoy Cruz, Guaymallén, Las Heras)    │
│ [NAVBAR] Logo + Nombre | ¿Sos Profesional? Sumate | Botón "Panel Pro"    │
├─────────────────────────────────────┬──────────────────┬─────────────────┤
│ [HÉROE + BUSCADOR INTERACTIVO]      │ [TARJETA OSCURA] │ [TARJETA MP]    │
│ • Badge: "Turnos verificados MZA"   │ Portal Pro       │ Garantía Seña   │
│ • Headline + Subheadline            │ "Atendés en MZA?"│ Mercado Pago    │
│ • Select Profesión | Select Zona    │ Botón: Alta Pro  │ Borde punteado  │
│ • Input texto libre + Tags filtros  │ (Fondo #1E293B)  │ (Fondo #72AEE6) │
├─────────────────────────────────────┴──────────────────┴─────────────────┤
│ [FILTROS RÁPIDOS PILLS] Todos | Médicos | Abogados | Contadores | Escrib. │
├──────────────────────────────────────────────────────────────────────────┤
│ [GRILLA DE PROFESIONALES]                                                │
│ ┌───────────────────────────────┐ ┌──────────────┐ ┌───────────────────┐ │
│ │ Card Destacada (2 Columnas)   │ │ Card Normal  │ │ Card Normal       │ │
│ └───────────────────────────────┘ └──────────────┘ └───────────────────┘ │
├──────────────────────────────────────────────────────────────────────────┤
│ [CÓMO FUNCIONA BENTO]                                                    │
│ [ 1. Elegí Profesional ]    [ 2. Aboná Seña MP ]    [ 3. WhatsApp 24hs ] │
├──────────────────────────────────────────────────────────────────────────┤
│ [FOOTER COMERCIAL]                                                       │
└──────────────────────────────────────────────────────────────────────────┘
```

### Paleta de colores

| Elemento | Color |
|----------|-------|
| Fondo general | `#F8FAFC` |
| Texto principal | `#1F2937` |
| Acento principal | `#0081C9` |
| Tarjeta oscura | `#1E293B` |
| Tarjeta Mercado Pago | Borde punteado `#72AEE6` |
| Bordes de tarjetas | `rounded-3xl` |

### Textos comerciales definitivos

- **Top Bar:** 📍 Portal Exclusivo para el Gran Mendoza (Ciudad, Godoy Cruz, Guaymallén y Las Heras) | 🔒 Señas protegidas por Mercado Pago
- **Headline:** Encontrá al profesional que necesitás hoy.
- **Subheadline:** Médicos, abogados, contadores y escribanos en Ciudad, Godoy Cruz, Guaymallén y Las Heras. Reservá tu turno online y asegurá tu cita con seña oficial.
- **Microcopy de búsqueda:** Buscar por especialidad, servicio o nombre (ej: cardiología, despidos, balances)...

---

## 2. Workflow del Paciente / Cliente

```
[Home / Buscador] ──► [Selección de Profesional] ──► [Modal Paso 1: Turno y Servicio]
                                                              │
[Confirmación + WhatsApp] ◄── [Checkout Mercado Pago] ◄── [Modal Paso 2: Datos de Contacto]
```

### Pasos detallados

1. **Descubrimiento y Filtro** — Selectores de Departamento y chips de categoría. Búsqueda reactiva.
2. **Ficha y Selección de Turno** — Selector de servicio (total vs seña), días disponibles, grilla de horarios.
3. **Formulario de Contacto** — Nombre, WhatsApp (prefijo 261), Email, DNI.
4. **Pago de Seña con Mercado Pago** — Desglose Total / Seña / Saldo.
5. **Confirmación** — Check de éxito + botón “Abrir WhatsApp del Consultorio” + email con .ics.

---

## 3. Workflow del Profesional

```
[Landing / CTA Pro] ──► [Wizard Onboarding 3 Pasos] ──► [Validación Matrícula]
                                                              │
[Gestión de Agenda y Señas] ◄── [Activación Plan / MP Connect] ◄┘
```

### Onboarding en 3 pasos

1. **Identidad y Matrícula** — Nombre, profesión, matrícula provincial, especialidad.
2. **Consultorio y Contacto** — Departamento, dirección, WhatsApp oficial.
3. **Aranceles y Mercado Pago** — Valor de consulta, monto/porcentaje de seña, vincular cuenta MP.

### Planes del profesional

| Característica | Plan Básico (Gratis - Mes 1) | Plan Profesional ($19.900–22.900) | Plan Destacado ($29.900–36.900) |
| --- | --- | --- | --- |
| Ficha Pública | Básica | Completa + Servicios | Badge "Destacado" |
| Cobro de Seña MP | Sí | Sí | Sí |
| Posición en Grilla | Estándar | Prioritaria | Top Bento (2 columnas) |
| Recordatorios WhatsApp | Manuales | Automáticos | Automáticos + logo |
| Comisión x Turno | 0% | 0% | 0% |

---

## 4. Roadmap de cierre del PMV

### Sprint 1 — Motor Transaccional (Semana 1)
- Estructura de base de datos Postgres
- Integración Mercado Pago Checkout Pro + webhook
- Conexión Resend para emails
- **Criterio de Done:** Flujo de pago de seña en Sandbox que impacta en DB

### Sprint 2 — UI Bento Grid y Reserva (Semana 2)
- Home Bento Grid responsivo con filtros por zona
- Modal/página de reserva en 4 pasos
- Enlace directo a WhatsApp preformateado
- **Criterio de Done:** Paciente puede filtrar, agendar, pagar y recibir confirmación en < 2 minutos

### Sprint 3 — Panel Profesional y Pilotos (Semana 3)
- Wizard de onboarding
- Dashboard con listado de turnos y métricas
- Carga de los primeros 15-20 profesionales
- **Criterio de Done:** 20 fichas completas verificadas y listas
