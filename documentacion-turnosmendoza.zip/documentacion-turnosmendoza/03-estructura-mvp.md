# Estructura del MVP — TurnosMendoza

**Objetivo del MVP:**  
Lanzar una versión mínima funcional que permita:
- Que un profesional se registre y publique su ficha completa
- Que un usuario busque, vea la ficha y reserve un turno
- Cobrar fee de despliegue + cuota mensual
- Integrar Mercado Pago para señas/cobros

---

## 1. Funcionalidades del MVP (priorizadas)

| Prioridad | Funcionalidad | Descripción | Usuario |
|-----------|---------------|-------------|---------|
| **P0** | Home + Buscador | Búsqueda por profesión, especialidad, zona y nombre | Público |
| **P0** | Ficha completa | Bio, servicios, ubicación (mapa), contacto, horarios, foto | Público |
| **P0** | Formulario de reserva | Selección de fecha/horario + datos del cliente + confirmación | Público |
| **P0** | Panel del profesional | Editar ficha, configurar horarios, ver y gestionar reservas | Profesional |
| **P0** | Alta / Onboarding | Formulario de registro + carga de datos básicos | Profesional |
| **P1** | Mercado Pago | Cobro de seña o pago total al reservar | Público / Profesional |
| **P1** | Recordatorios básicos | Email de confirmación y recordatorio 24 hs antes | Sistema |
| **P1** | Planes y cobro de cuota | Control de plan activo (Gratis / Profesional / Destacado) | Admin / Profesional |
| **P2** | Mapa básico | Mostrar ubicación del consultorio | Público |
| **P2** | Listado de zonas | Filtro rápido por las 4 zonas de Mendoza | Público |

---

## 2. Roles de usuario

1. **Visitante / Cliente** → Busca → ve ficha → reserva → recibe confirmación
2. **Profesional** → Se registra → completa ficha → configura agenda → recibe reservas → paga cuota
3. **Administrador** → Aprueba altas, gestiona planes, ve métricas básicas

---

## 3. Entidades principales (modelo de datos)

- **Usuario** (email, contraseña, rol, datos de contacto)
- **Profesional** (vinculado a Usuario)
  - Datos personales + matrícula/colegio
  - Bio, foto, servicios, especialidades
  - Ubicación (dirección, zona, lat/lng)
  - Horarios de atención
  - Plan actual y estado de pago
- **Servicio** (nombre, duración, precio orientativo)
- **Disponibilidad / Slot** (día, hora inicio, hora fin, estado)
- **Reserva** (profesional, cliente, fecha/hora, estado, datos del cliente, pago)
- **Pago** (Mercado Pago preference/id, monto, estado)

---

## 4. Flujos principales

### Flujo Cliente
1. Llega al Home
2. Busca o filtra por zona/profesión
3. Entra a la ficha
4. Elige fecha y horario disponible
5. Completa formulario (nombre, teléfono, email, motivo)
6. (Opcional) Paga seña con Mercado Pago
7. Recibe confirmación por email

### Flujo Profesional
1. Se registra
2. Completa ficha (paso a paso)
3. Configura horarios y servicios
4. Activa plan (paga cuota vía Mercado Pago)
5. Ve reservas entrantes y las confirma/cancela
6. Recibe notificaciones de nuevas reservas

---

## 5. Criterios de “MVP listo para lanzar”

- Un profesional puede registrarse y tener su ficha pública en menos de 15 minutos
- Un usuario encuentra un profesional de su zona y reserva en menos de 2 minutos
- Se puede cobrar seña y cuota mensual con Mercado Pago
- Existen al menos las 4 zonas de Mendoza como filtros
- El sistema envía email de confirmación
- Hay un panel mínimo para que el profesional gestione sus turnos

---

## 6. Qué queda explícitamente fuera del PMV

1. Historias clínicas digitales complejas
2. Chat interno en tiempo real (se resuelve con WhatsApp)
3. Facturación electrónica automática con AFIP
4. Múltiples sucursales complejas por un mismo profesional
5. IA avanzada o recomendaciones automáticas
