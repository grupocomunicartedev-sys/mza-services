# Guía Maestra de Migración a Producción — TurnosMendoza

**Stack final:**  
Next.js 15 (App Router) + TypeScript + Prisma (PostgreSQL / Neon) + Auth.js (NextAuth v5) + Mercado Pago Checkout Pro + Tailwind CSS + Resend

---

## 1. Estructura de carpetas (App Router)

```
turnos-mendoza/
├── prisma/
│   ├── schema.prisma
│   └── seed.ts
├── public/
├── src/
│   ├── app/
│   │   ├── (auth)/
│   │   │   ├── login/page.tsx
│   │   │   └── registro/page.tsx
│   │   ├── (dashboard)/
│   │   │   └── dashboard/
│   │   │       ├── layout.tsx
│   │   │       ├── page.tsx
│   │   │       ├── turnos/page.tsx
│   │   │       ├── aranceles/page.tsx
│   │   │       └── plan/page.tsx
│   │   ├── (public)/
│   │   │   ├── layout.tsx
│   │   │   ├── page.tsx                    # Home Bento Grid
│   │   │   ├── profesional/[id]/page.tsx
│   │   │   └── reserva/[profesionalId]/page.tsx
│   │   ├── api/
│   │   │   ├── auth/[...nextauth]/route.ts
│   │   │   ├── bookings/route.ts
│   │   │   └── mercadopago/
│   │   │       ├── create-preference/route.ts
│   │   │       └── webhook/route.ts
│   │   ├── globals.css
│   │   └── layout.tsx
│   ├── components/
│   │   ├── booking/
│   │   ├── dashboard/
│   │   ├── home/
│   │   └── ui/
│   ├── lib/
│   │   ├── auth.ts
│   │   ├── email.ts
│   │   ├── mercadopago.ts
│   │   ├── prisma.ts
│   │   └── utils.ts
│   ├── middleware.ts
│   └── types/
├── .env.example
├── next.config.mjs
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

---

## 2. Modelos principales de Prisma

- **User** → id, name, email, passwordHash, role
- **Professional** → title, profession, specialty, licenseNumber, zone, address, phone, plan, mpAccessToken, isFeatured
- **Service** → name, durationMinutes, totalPrice, depositPrice
- **Appointment** → code, patientName, patientDni, patientPhone, patientEmail, date, status, totalAmount, depositAmount, mpPaymentId, mpPreferenceId
- **AvailabilityRule** → dayOfWeek, startTime, endTime, slotDuration

**Enums clave:**
- `ProfessionCategory`: MEDICOS | ABOGADOS | CONTADORES | ESCRIBANOS
- `MendozaZone`: CIUDAD | GODOY_CRUZ | GUAYMALLEN | LAS_HERAS
- `PlanType`: FREE_TRIAL | PROFESIONAL | DESTACADO
- `AppointmentStatus`: PENDING_PAYMENT | CONFIRMED | CANCELLED | COMPLETED

---

## 3. Rutas principales

| Ruta | Tipo | Descripción |
|------|------|-------------|
| `/` | Pública | Home comercial Bento Grid |
| `/profesional/[id]` | Pública | Ficha completa |
| `/reserva/[profesionalId]` | Pública | Flujo de reserva en 4 pasos |
| `/login` | Auth | Login de profesionales |
| `/registro` | Auth | Wizard de onboarding |
| `/dashboard` | Privada | Panel principal + métricas |
| `/dashboard/turnos` | Privada | Listado de reservas |
| `/dashboard/aranceles` | Privada | Gestión de servicios y señas |
| `/dashboard/plan` | Privada | Estado de suscripción y MP |
| `/api/mercadopago/create-preference` | API | Crear preferencia de pago |
| `/api/mercadopago/webhook` | API | Confirmar pago y actualizar reserva |

---

## 4. Plan de migración paso a paso

1. **Inicialización** → `npx create-next-app@latest` + dependencias
2. **Base de datos** → Configurar Neon/Supabase + `prisma db push` + seed
3. **Home** → Migrar lógica de App.tsx a `page.tsx` con Prisma
4. **Reserva** → Convertir BookingModal en ruta `/reserva/[profesionalId]`
5. **Auth + Onboarding** → NextAuth + páginas `/login` y `/registro`
6. **Webhooks + Emails** → Mercado Pago real + Resend

---

## 5. Variables de entorno necesarias

```env
NEXT_PUBLIC_APP_URL="http://localhost:3000"
DATABASE_URL="postgresql://..."
AUTH_SECRET="..."
NEXTAUTH_URL="http://localhost:3000"
MP_ACCESS_TOKEN="APP_USR-..."
NEXT_PUBLIC_MP_PUBLIC_KEY="APP_USR-..."
RESEND_API_KEY="re_..."
EMAIL_FROM="TurnosMendoza <notificaciones@turnosmendoza.com.ar>"
```

---

## 6. Alternativas de hosting recomendadas (vs Vercel)

| Plataforma | Precio aprox. | Mejor para |
|------------|---------------|------------|
| **Cloudflare Pages** | $0–5/mes | Costo + performance |
| **Railway** | $5–20/mes | Full-stack + DB fácil |
| **Render** | $7–25/mes | Full-stack confiable |
| **Hetzner + Coolify** | $4–8/mes | Máximo control y precio bajo |
| **Netlify** | $0–19/mes | Similar a Vercel |
