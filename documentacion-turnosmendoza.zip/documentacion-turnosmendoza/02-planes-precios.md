# Estructura de Planes de Precios — TurnosMendoza

**Mercado:** Argentina (pesos)  
**Integración:** Mercado Pago  
**Modelo:** Fee de despliegue + cuota mensual de mantenimiento  
**Fecha:** Agosto 2026

---

## 1. Fee de Despliegue (pago único)

| Concepto | Precio orientativo | Qué incluye |
|----------|--------------------|-------------|
| **Alta Básica** | $45.000 – $65.000 | Carga de ficha, foto, bio, servicios, ubicación, horarios |
| **Alta Completa + Capacitación** | $80.000 – $120.000 | Todo lo anterior + verificación, integración Mercado Pago, capacitación |
| **Estudio / Multi-profesional** | Desde $150.000 | Varios profesionales + branding del centro |

**Recomendación de lanzamiento:**  
Fee de Alta Completa en promoción: **$89.000**

---

## 2. Planes Mensuales

| Plan | Precio mensual (ARS) | Ideal para | Funcionalidades principales | Mercado Pago |
|------|----------------------|------------|-----------------------------|--------------|
| **Gratis / Básico** | $0 | Prueba | Ficha básica, sin reserva o límite bajo | No |
| **Profesional** | $18.000 – $25.000 | Independientes | Ficha completa + agenda ilimitada + recordatorios + posicionamiento normal | Sí |
| **Destacado** | $32.000 – $42.000 | Más visibilidad | Todo lo anterior + mejor posición + reseñas destacadas + WhatsApp automático | Sí + reportes |
| **Estudio / Multi** | $55.000 – $85.000 | Clínicas o estudios 2-5 profesionales | Multi-usuario, agendas independientes, branding | Sí |

### Precios recomendados de lanzamiento

| Plan | Precio |
|------|--------|
| Profesional | **$22.900 / mes** |
| Destacado | **$36.900 / mes** |

---

## 3. Integración Mercado Pago

Incluida desde el plan **Profesional**:

- Cobro de seña o anticipo al reservar (el profesional define % o monto fijo)
- Cobro total de la consulta (opcional)
- El dinero ingresa directamente a la cuenta del profesional
- 0% comisión de la plataforma sobre el cobro (solo comisión estándar de Mercado Pago)
- Reportes de cobros y saldos

---

## 4. Comparación con el mercado local

- Más accesible que Doctoralia AR (Starter ~$25.000 y sube rápido)
- Competitivo con Turnito Advance (~$21.000), ReservaSimple Premium (~$17.000) y AgendaPro
- Superior en valor porque suma **directorio público + multi-profesión + foco geográfico Mendoza**

---

## 5. Promociones sugeridas de lanzamiento

- Primeros 50 profesionales: fee de alta al 50% + 1er mes gratis
- Pago anual del plan Profesional: 2 meses de bonificación
- Referidos: descuento en la cuota del mes siguiente
